package com.ircclouds.irc.api.domain.messages.interfaces;

/**
 * 
 * @author
 * 
 */
public interface IChannelMessage
{
	String getChannelName();
}
