package com.ircclouds.irc.api.filters;

public enum FilterStatus
{
	PASS, HALT
}
