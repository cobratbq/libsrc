package com.ircclouds.irc.api.domain;

public class ChannelModeD extends ChannelMode
{
	public ChannelModeD(Character aType)
	{
		super(aType);
		
	}
}
