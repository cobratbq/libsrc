package com.ircclouds.irc.api.ctcp;

import com.ircclouds.irc.api.*;

public interface DCCReceiveCallback extends ICallback<DCCReceiveResult, DCCReceiveException>
{

}
