package com.ircclouds.irc.api;

public interface DCCManager
{
	int activeDCCSendsCount();

	int activeDCCReceivesCount();
	
	/* Add more stats */
}
