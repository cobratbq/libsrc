package com.ircclouds.irc.api.om;

public class IRCOMException extends RuntimeException
{
	public IRCOMException(Exception aExc)
	{
		super(aExc);
	}
}
